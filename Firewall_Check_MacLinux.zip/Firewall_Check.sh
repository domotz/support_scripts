#!/bin/bash
COLOR='\033[1;33m'
NC='\033[0m'
RED='\033[0;31m'
echo -e "${COLOR}Firewall Check - Domotz Pro"
echo ""
echo -e "If any service fails please review your Firewall rules to allow the service. ${NC}"
echo ""
echo -e "${COLOR}TESTING EU SERVERS ${NC}"
        nc -zv api-eu-west-1-cell-1.domotz.com 443
        nc -zv portal.domotz.com 443
        nc -zv messaging-eu-west-1-cell-1.domotz.com 5671
echo ""
echo -e "${COLOR}TESTING US SERVERS ${NC}"
        nc -zv api-us-east-1-cell-1.domotz.com 443
        nc -zv portal.domotz.com 443
        nc -zv messaging-us-east-1-cell-1.domotz.com 5671
echo ""
ping -c 4 echo.domotz.com
echo ""
echo -e "${COLOR}If you are using a Domotz Box these are used for automated upgrades of the packages and provisioning channel:"
echo ""
echo -e "B-11, B-001, B-003 models (It has a HDMI port)${NC}:"
nc -zv provisioning.domotz.com 4505
nc -zv provisioning.domotz.com 4506
nc -zv pool.sks-keyservers.net 11371
echo ""
echo -e "${COLOR}B-12 model (Doesn't have a HDMI port):${NC}"
nc -zv messaging.orchestration.domotz.com 5671
nc -zv api.orchestration.domotz.com 443
echo -e "${RED}If you need support contact: support@domotz.com."
echo -e "${COLOR}END"