Domotz Inc.

Scripts provided:

- sshd_mgmnt.sh (to enable/disable the sshd service)
- domotz_cloud_diagnostics.sh (to check the if the firewall is correcly setup to allow outgoing connections to the Domotz cloud)
- network_config.sh (to configure your network to setup a static ip address, etc.)
- add_vlans.sh (to add VLANs for VLAN monitoring with Domotz)