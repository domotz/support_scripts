DISCLAIMER
The script Set-WmiNamespaceSecurity.ps1 has not been developed by Domotz, but instead it has been downloaded from the website:
https://knowledgebase.paloaltonetworks.com/KCSArticleDetail?id=kA10g000000ClcsCAC

So, USE IT AT YOUR OWN RISK.


HOW TO USE:
unzip the file inside the same directory where the enable_ssh_os_monitoring.ps1 reside and run again the enable_ssh_os_monitoring.ps1 script.